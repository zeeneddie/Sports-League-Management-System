=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

 HollandseVelden iconset
	> http://www.hollandsevelden.nl/iconset/

=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=



De HollandseVelden.nl iconset is een gratis set 
van meer dan 1000 iconen in PNG formaat 
(32x32 pixels). De set valt onder een 
Creative Commons Attribution 2.5 Licentie, 
wat betekent dat je de iconen overal voor kunt 
gebruiken (behalve soortgelijke/concurrerende 
websites) en ze desgewenst mag aanpassen. Het 
enige wat wij ervoor terug vragen is een 
bronvermelding (in de vorm van een duidelijk 
zichtbare link naar HollandseVelden.nl) op de 
pagina's waar de iconen worden gebruikt.


    * Creative Commons Attribution 2.5 Licentie
    	> http://creativecommons.org/licenses/by/2.5/

    * Bekijk de Hollandsevelden iconset
    	> http://www.hollandsevelden.nl/downloads/HollandseVelden-iconset-20130811.png

    * Download de Hollandsevelden iconset (32x32 pixels)
		> http://www.hollandsevelden.nl/iconset/


Bijna wekelijks voegen wij nieuwe iconen toe aan 
deze set. Mocht er toch nog een tenue zijn dat je 
mist, laat het ons de even weten! Stuur wel een 
link naar een foto mee waarop we kunnen zien hoe 
het shirt eruit moet komen te zien, en wij maken 
er zo snel mogelijk een icoon van!


    * Contact
		> http://www.hollandsevelden.nl/contact/
